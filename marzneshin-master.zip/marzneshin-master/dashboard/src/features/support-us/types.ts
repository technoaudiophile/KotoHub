
export type SupportUsVariation = "status" | "local-storage" | "view"
export type SupportUsStructure = "card" | "popover"

