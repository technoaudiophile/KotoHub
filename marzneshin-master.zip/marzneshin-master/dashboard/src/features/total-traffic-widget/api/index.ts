export * from "./total-traffic.query";
