
export interface ServiceType {
    id: number;
    name: string;
    user_ids: number[];
    inbound_ids: number[];
}
