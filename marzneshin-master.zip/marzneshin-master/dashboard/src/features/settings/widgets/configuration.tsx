
import { SectionWidget } from "@marzneshin/components";

export const ConfigurationWidget = () => {
    return (
        <SectionWidget description="" title="System Configuration">
            Config fields
        </SectionWidget>
    )
}
