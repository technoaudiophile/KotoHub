import { AdminType } from "@marzneshin/modules/admins";

export interface AdminProp {
    admin: AdminType;
}
