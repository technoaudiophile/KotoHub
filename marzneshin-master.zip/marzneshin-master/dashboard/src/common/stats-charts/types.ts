
export type ChartDateInterval = '90d' | '30d' | '7d' | '1d';
